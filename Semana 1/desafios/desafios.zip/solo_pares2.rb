n=ARGV[0].to_i

i=0

n.times do |b|
    print i+2
    i +=2    
end