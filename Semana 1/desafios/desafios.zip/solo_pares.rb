n=ARGV[0].to_i

i=-2

n.times do |b|
    print i+2 
    i +=2    
end

