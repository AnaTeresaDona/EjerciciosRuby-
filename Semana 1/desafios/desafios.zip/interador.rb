i=0
50.times do |i|
    puts "Iteración #{i}"
    i=i+1
end