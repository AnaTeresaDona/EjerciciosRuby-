n=ARGV[0].to_i
i=0
total=0

n.times do |b|
    i+2 
    i +=2  
    total+=i  
end
puts total