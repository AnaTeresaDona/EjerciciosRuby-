
n = ARGV[0].to_i

i = 1
numeros = ""

n.times do
numeros += i.to_s
i += 1
print "#{numeros} "
end 
